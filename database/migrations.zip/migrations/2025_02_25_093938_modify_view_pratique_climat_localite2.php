<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

class ModifyViewPratiqueClimatLocalite2 extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::statement(' 
            CREATE OR REPLACE VIEW "viewPratiqueClimatLocalite" AS
            SELECT 
                "pz"."pratique_id",
                "pz"."localite_id",
                "pc"."climat_id",
                "l"."typeLocalite_id",
                "l"."typeLocaliteLibelle",
                "l"."p0",
                "l"."pays",
                "ll"."nomLocalite",
                "l"."p1",
                "l"."libelle1",
                "l"."p2",
                "l"."libelle2",
                "l"."p3",
                "l"."libelle3",
                "l"."p4",
                "l"."libelle4",
                "l"."codeAlpha3",
                "l"."centroid",
                "pz"."longitude",
                "pz"."latitude",
                "pz"."geom",
                "p"."pratiqueLibelle",
                "p"."description",
                "p"."objectif",
                "p"."periodeDebut",
                "p"."periodeFin",
                "p"."avantage",
                "p"."contrainte",
                "p"."cout",
                "p"."conseil",
                "p"."mesure",
                "p"."description_env_humain",
                "p"."recommandation",
                "p"."defis",
                "p"."publique",
                "p"."user_id",
                "p"."vedette_path",
                "p"."created_at",
                "p"."updated_at",
                "pd"."domaine_id",
                "d"."domaineLibelle",
                "ps"."sol_id",
                "s"."solLibelle"
            FROM "pratiquezoneapplis" "pz"
            JOIN "pratiques" "p" ON "pz"."pratique_id" = "p"."pratique_id"
            LEFT JOIN "pratiqueclimats" "pc" ON "p"."pratique_id" = "pc"."pratique_id"
            JOIN "viewLocalite" "l" ON "pz"."localite_id" = "l"."localite_id"
            JOIN "listeLocalite" "ll" ON "l"."localite_id" = "ll"."localite_id"
            JOIN "pratiquedomaines" "pd" ON "p"."pratique_id" = "pd"."pratique_id"
            JOIN "domaines" "d" ON "pd"."domaine_id" = "d"."domaine_id"
            LEFT JOIN "pratiquesols" "ps" ON "p"."pratique_id" = "ps"."pratique_id"
            LEFT JOIN "sols" "s" ON "ps"."sol_id" = "s"."sol_id"
            WHERE "p"."deleted_at" IS NULL
              AND "p"."publique" = true
        ');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('DROP VIEW IF EXISTS "viewPratiqueClimatLocalite"');
    }
}
